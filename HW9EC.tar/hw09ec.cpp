/* ======================================================================================= */
/* ======================================================================================= */
// Class: CS-1C
// Creator: Joshua Yang
// Contact: joshuayang0324@gmail.com
// Professor: Kath
// Date: 3/5/2019
/* ======================================================================================= */
/* ======================================================================================= */
// Work: 
// CS1C Spring 2019 TTH HW-1 50pts Due: Th 1/24/2019
// cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ script hw01.scr
// Script started, file is hw01.scr
// cs1c@cs1c-VirtualBox ~/cs1c/hw01 $ date
// ... 
// Cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ Is -1
// ... 
// Cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ make all
// ...
// Cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ Is -1
// ...
// Cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ ./hw01
// ...//print out parts a, d & g above
// cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ exit
// Script done, file is hw01.scr
// Cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ make tar
// ...
// Submit the tar package file hw01.tar by Thursday January 24, 2019.
/* ======================================================================================= */
/* ======================================================================================= */
// Code:


#include <iostream>
#include <cmath>
using namespace std;

class Shape
{
public:
    Shape(int x = 0, int y = 0) :
            x
            { x }, y
            { y }
    {
    }

    void Print()
    {
        cout << "This is Shape with x = " << x << ", y = " << y << endl;
    }
    virtual void Move()
    {
        cout << "Call Move() function for Shape object" << endl;
    }
    virtual void UpdateDimensions()
    {
        cout << "Enter new x-coordinator for Shape: ";
        cin >> x;
        cout << "Enter new y-coordinator for Shape: ";
        cin >> y;
    }
private:
    int x;  // x-coordinate
    int y;  // y-coordinate
};

class Circle: public Shape
{
public:
    Circle(int r) :
            r
            { r }
    {
    }
    void Print()  // static polymorphism
    {
        cout << "This is Circle with radius = " << r << endl;
    }
    void UpdateDimensions()  // dynamic polymorphism
    {
        cout << "Enter new radius for Circle: ";
        cin >> r;
    }
private:
    int r;  // radius
};

class Rectangle: public Shape
{
public:
    Rectangle(int l, int w) :
            l
            { l }, w
            { w }
    {
    }
    void Print()  // static polymorphism
    {
        cout << "This is Rectangle with length = " << l << ", width = " << w << endl;
    }
    void UpdateDimensions()  // dynamic polymorphism
    {
        cout << "Enter new length for Rectangle: ";
        cin >> l;
        cout << "Enter new width for Rectangle: ";
        cin >> w;
    }
private:
    int l;  // length
    int w;  // width
};

//prototye of DrawShape
void DrawShape(Shape *obj)
{
    obj->Move();
    obj->UpdateDimensions();
}

int main(int agrc, char* agrv[])
{
    cout << "Create new Shape(4,5):" << endl;
    Shape *shape = new Shape(4, 5);
    cout << "After create Shape object: " << endl;
    shape->Print();
    cout << "Call DrawShape(shape) function: " << endl;
    DrawShape(shape);
    cout << "After call DrawShape(shape): " << endl;
    shape->Print();
    cout << endl;

    cout << "Create new Circle(6): " << endl;
    Shape *circle = new Circle(6);
    cout << "After create Circle object: " << endl;
    cout << "Without cast to Circle object:" << endl;
    cout << "\t";
    circle->Print();
    cout << "With cast to Circle object:" << endl;
    cout << "\t";
    static_cast<Circle*>(circle)->Print();
    cout << "Call DrawShape(circle) function: " << endl;
    DrawShape(circle);
    cout << "After call DrawShape(circle): " << endl;
    cout << "Without cast to Circle object:" << endl;
    cout << "\t";
    circle->Print();
    cout << "With cast to Circle object:" << endl;
    cout << "\t";
    static_cast<Circle*>(circle)->Print();
    cout << endl;

    cout << "Create new Rectangle(4,5): " << endl;
    Shape *rectangle = new Rectangle(4, 5);
    cout << "After create Rectangle object: " << endl;
    cout << "Without cast to Rectangle object:" << endl;
    cout << "\t";
    rectangle->Print();
    cout << "With cast to Rectangle object:" << endl;
    cout << "\t";
    static_cast<Rectangle*>(rectangle)->Print();
    cout << "Call DrawShape(rectangle) function: " << endl;
    DrawShape(rectangle);
    cout << "After call DrawShape(rectangle): " << endl;
    cout << "Without cast to Rectangle object:" << endl;
    cout << "\t";
    rectangle->Print();
    cout << "With cast to Rectangle object:" << endl;
    cout << "\t";
    static_cast<Rectangle*>(rectangle)->Print();
    cout << endl;

    cout << "Question 3: Do we need to override Move for derived classed?" << endl;
    cout << "Answer: No need to override Move. " << endl
            << "If we don't override the Move() function, the object will call with base class implement." << endl
            << endl;

    cout << "Question 4: What kind of binding is occurring for Print vs UpdateDimensions?" << endl;
    cout << "Answer:" << endl;
    cout << "\t- Print() is static polymorphism, this is completely resolved at compile time" << endl;
    cout << "\t- UpdateDimensions() is dynamic polymorphism, this is defers binding at runtime" << endl << endl;

    cout << "Question 5: Explain the importance of Interface Inheritance and how this applies to DrawShape." << endl;
    cout << "Answer: " << endl;
    cout
            << "\t- An interface describes the behavior or capabilities of a C++ class without committing to a particular implementation of that class."
            << endl;
    cout
            << "\t-The purpose of an abstract class is to provide an appropriate base class from which other classes can inherit"
            << endl;
    cout << "\t-In the DrawShape:" << endl;
    cout
            << "\t\t+ Move() function was not override by subclass (Circle and Rectangle). So when call this will be reference to implement in base class."
            << endl;
    cout
            << "\t\t+ UpdateDimensions() function is override in sub-class. So when call this will be reference to sub-class implement"
            << endl;

}

